/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['teamstitchpros.com'],
  },
};

export default nextConfig;
